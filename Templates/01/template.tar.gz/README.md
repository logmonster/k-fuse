# k-fuse
project to provide templates for kick starting code projects based on types / archetypes

## architecture

| language | nodeJs |
|:----------:|:----------------:|
|libraries| commander |


